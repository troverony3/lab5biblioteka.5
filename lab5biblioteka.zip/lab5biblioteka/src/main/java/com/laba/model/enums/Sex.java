package com.laba.model.enums;

public enum Sex {
    MALE,
    FEMALE;
}
