package com.laba.gui; //установить значние путь файла по умолчанию

import com.laba.model.*;
import com.laba.service.ExcelReaderService;
import com.laba.service.XlsxReaderServiceImpl;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GUI extends JFrame {

    private final JFileChooser fileChooserUser = new JFileChooser();
    private final JFileChooser fileChooserBook = new JFileChooser();
    private JTree jTree;

    private List<User> users;
    private List<Book> books;

    public GUI() {
        super("form");
        fileChooserBook.setSelectedFile(new File(""));//прописать сдесь путь
        fileChooserUser.setSelectedFile(new File(""));//прописать сдесь путь
        this.setBounds(300, 300, 500, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container contentPane = this.getContentPane();
        contentPane.setLayout(new GridBagLayout()); //потом надо погуглить


        DefaultMutableTreeNode top = new DefaultMutableTreeNode("Библиотека");
        jTree = new JTree(top);

        JButton importUsersButton = new JButton("Import users");
        importUsersButton.addActionListener(actionEvent -> {
            int returnValue = fileChooserUser.showOpenDialog(GUI.this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooserUser.getSelectedFile();
                ExcelReaderService readerService = XlsxReaderServiceImpl.of();
                try {
                    users = readerService.readUsers(selectedFile.getAbsolutePath());
                    JOptionPane.showMessageDialog(null, "Done", "Import", JOptionPane.PLAIN_MESSAGE);
                } catch (IOException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "файл не существует", "Error", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

        JButton importBooksButton = new JButton("Import books");
        importBooksButton.addActionListener(actionEvent -> {
            int returnValue = fileChooserBook.showOpenDialog(GUI.this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooserBook.getSelectedFile();
                ExcelReaderService readerService = XlsxReaderServiceImpl.of();
                try {
                    books = readerService.readBooks(selectedFile.getAbsolutePath());
                    JOptionPane.showMessageDialog(null, "Done", "Import", JOptionPane.PLAIN_MESSAGE);
                } catch (IOException e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, "файл не существует", "Error", JOptionPane.PLAIN_MESSAGE);
                }
            }
        });

        JButton buildTreeButton = new JButton("Show tree");
        buildTreeButton.addActionListener(actionEvent -> {
            if (users != null && books != null) {
                ExcelReaderService readerService = XlsxReaderServiceImpl.of();
                readerService.issueBooks(users, books);
                fillTree(top, users);
            } else {
                JOptionPane.showMessageDialog(null, "сначала нужно импортировать пользователей и книги", "Error", JOptionPane.PLAIN_MESSAGE);
            }
        });

        GridBagConstraints buttonConstraints = new GridBagConstraints();
        buttonConstraints.weightx = 0.5;
        buttonConstraints.fill = GridBagConstraints.HORIZONTAL;
        buttonConstraints.gridx = 0;
        buttonConstraints.gridy = 0;

        GridBagConstraints treeConstraints = new GridBagConstraints();
        treeConstraints.fill = GridBagConstraints.HORIZONTAL;
        treeConstraints.anchor = GridBagConstraints.PAGE_END;//приязываем список к низу
        treeConstraints.gridwidth = 3;
        treeConstraints.gridy = 1;

        contentPane.add(importUsersButton, buttonConstraints);
        buttonConstraints.gridx = 1;
        contentPane.add(importBooksButton, buttonConstraints);
        buttonConstraints.gridx = 2;
        contentPane.add(buildTreeButton, buttonConstraints);
        JScrollPane scrollPane = new JScrollPane(jTree, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        contentPane.add(scrollPane, treeConstraints);
    }

    private void fillTree(DefaultMutableTreeNode top, List<User> users) {
        DefaultTreeModel tr = (DefaultTreeModel) jTree.getModel();

        DefaultMutableTreeNode teachers = new DefaultMutableTreeNode("Преподаватели");
        DefaultMutableTreeNode students = new DefaultMutableTreeNode("Студенты");
        top.add(teachers);
        top.add(students);
        users.forEach(user -> {
            DefaultMutableTreeNode userNode;
            if (user instanceof Teacher) {
                userNode = new DefaultMutableTreeNode(user.getLastName() + " " + user.getFirstName() + " " + ((Teacher) user).getMiddleName());
                teachers.add(userNode);
            } else {
                userNode = new DefaultMutableTreeNode(user.getLastName() + " " + user.getFirstName());
                students.add(userNode);
            }
            user.getBooks().forEach(book -> {
                DefaultMutableTreeNode bookNode = new DefaultMutableTreeNode(book.getTitle());
                userNode.add(bookNode);
                List<String> bookProps = new ArrayList<>();//для всех параметров книги
                bookProps.add("Язык: " + book.getLanguage().getLangName());
                if (book.getAuthor() != null) {
                    bookProps.add("Автор: " + book.getAuthor());
                }
                if (book instanceof BookScienceEng) {
                    bookProps.add("Уровень: " + ((BookScienceEng) book).getLevel().getLevelName());
                    bookProps.add("Университет: " + ((BookScienceEng) book).getUniversity());
                } else if (book instanceof BookScienceRus) {
                    bookProps.add("Тип: " + ((BookScienceRus) book).getType());
                }
                bookProps.forEach(prop -> bookNode.add(new DefaultMutableTreeNode(prop))); //все строчки для книги добавляем
            });
        });
        tr.reload();
    }

}
