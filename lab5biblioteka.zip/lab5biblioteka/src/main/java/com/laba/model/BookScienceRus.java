package com.laba.model;

public class BookScienceRus extends BookScience {

    private String type;

    public BookScienceRus() {
    }

    public String getType() {
        return type;
    }

    public BookScienceRus setType(String type) {
        this.type = type;
        return this;
    }
}
