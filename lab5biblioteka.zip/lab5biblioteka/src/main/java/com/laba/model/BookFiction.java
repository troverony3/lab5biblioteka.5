package com.laba.model;

public class BookFiction extends Book {

    public BookFiction() {
    }
}
