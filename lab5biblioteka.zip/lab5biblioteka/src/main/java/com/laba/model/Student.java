package com.laba.model;

public class Student extends User {
}
