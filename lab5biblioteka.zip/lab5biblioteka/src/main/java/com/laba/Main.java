package com.laba;

import com.laba.gui.GUI;

public class Main {
    public static void main(String[] args) {
        GUI mainFrame = new GUI();
        mainFrame.setVisible(true);
    }
}
