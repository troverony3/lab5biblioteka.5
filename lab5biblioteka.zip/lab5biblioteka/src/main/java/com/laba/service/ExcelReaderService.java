package com.laba.service; ///переделать нормально класс с чтением
//открыть эксель 1 раз, а не 4

import com.laba.model.*;
import com.laba.model.enums.Language;
import com.laba.model.enums.Level;
import com.laba.model.enums.Sex;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

// класс с шаблонными методами
public abstract class ExcelReaderService {

    // листы англоязычных научных книг
    private static final String EN_SCIENCE_BOOK_SHEET = "en_sc";
    private static final String EN_SUBJECT_SHEET = "en_уч";
    private static final String EN_UNIVERSITY_SHEET = "en_un";
    private static final String EN_SCIENCE_AUTHOR_SHEET = "en_au";

    // листы русскоязычных научных книг
    private static final String RU_SCIENCE_BOOK_SHEET = "ru_sc";
    private static final String RU_SUBJECT_SHEET = "ру_уч";
    private static final String RU_TYPE_SHEET = "ру_тип";

    // листы англоязычного фикшена
    private static final String EN_FICTION_BOOK_SHEET = "en_fic";
    private static final String EN_FICTION_AUTHOR_SHEET = "en_fic_au";

    // листы русскоязычного фикшена
    private static final String RU_FICTION_BOOK_SHEET = "ру_фик";
    private static final String RU_FICTION_AUTHOR_SHEET = "ру_авт";

    // листы пользователей
    private static final String MALE_NAME_SHEET = "name";
    private static final String FEMALE_NAME_SHEET = "w_name";
    private static final String STUDENT_SURNAME_SHEET = "surname";
    private static final String TEACHER_SURNAME_SHEET = "prof_surname";
    private static final String TEACHER_MIDDLENAME_SHEET = "middlename";

    // границы для распределения книг
    private static final int MIN_NUMBER_OF_BOOKS_INCLUDED = 3;
    private static final int MAX_NUMBER_OF_BOOKS_EXCLUDED = 11;

    public void issueBooks(List<User> users, List<Book> books) {    //для каждого пользователя распределяем книги
        users.forEach(user -> {
            Collections.shuffle(books);//перемешивание
            user.getBooks().addAll(
                    books.subList(0, MIN_NUMBER_OF_BOOKS_INCLUDED + ThreadLocalRandom.current().nextInt(MAX_NUMBER_OF_BOOKS_EXCLUDED - MIN_NUMBER_OF_BOOKS_INCLUDED)));
        });
    }

    public List<Book> readBooks(String filename) throws IOException {
        Workbook workbook = getWorkbook(filename);
        List<Book> allBooks = new ArrayList<>();
        allBooks.addAll(readFiction(workbook, Language.EN));
        allBooks.addAll(readFiction(workbook, Language.RU));
        allBooks.addAll(readScience(workbook, Language.EN));
        allBooks.addAll(readScience(workbook, Language.RU));
        return allBooks;
    }

    private List<Book> readScience(Workbook workbook, Language language) {
        List<Book> books = new ArrayList<>();
        if (language.equals(Language.EN)) {
            fillEnScience(workbook, books);
        } else {
            fillRuScience(workbook, books);
        }
        return books;
    }

    private void fillEnScience(Workbook workbook, List<Book> books) {
        Sheet bookNamesSheet = workbook.getSheet(EN_SCIENCE_BOOK_SHEET);
        bookNamesSheet.rowIterator()
                .forEachRemaining(row -> books.add(new BookScienceEng().setLanguage(Language.EN).setTitle(row.getCell(0).getStringCellValue())));
        Sheet subjectsSheet = workbook.getSheet(EN_SUBJECT_SHEET);
        Sheet universitiesSheet = workbook.getSheet(EN_UNIVERSITY_SHEET);
        Sheet authorsSheet = workbook.getSheet(EN_SCIENCE_AUTHOR_SHEET);
        List<String> subjects = new ArrayList<>();
        List<String> universities = new ArrayList<>();
        List<String> authors = new ArrayList<>();
        subjectsSheet.rowIterator().forEachRemaining(row -> subjects.add(row.getCell(0).getStringCellValue()));
        universitiesSheet.rowIterator().forEachRemaining(row -> universities.add(row.getCell(0).getStringCellValue()));
        authorsSheet.rowIterator().forEachRemaining(row -> authors.add(row.getCell(0).getStringCellValue()));
        books.forEach(book -> {
            book.setAuthor(authors.get(ThreadLocalRandom.current().nextInt(authors.size())));
            ((BookScience) book).setSubject(subjects.get(ThreadLocalRandom.current().nextInt(subjects.size())));
            ((BookScienceEng) book).setLevel(Level.values()[ThreadLocalRandom.current().nextInt(Level.values().length)]);
            ((BookScienceEng) book).setUniversity(universities.get(ThreadLocalRandom.current().nextInt(universities.size())));
        });
    }

    private void fillRuScience(Workbook workbook, List<Book> books) {
        Sheet bookNamesSheet = workbook.getSheet(RU_SCIENCE_BOOK_SHEET);
        bookNamesSheet.rowIterator()
                .forEachRemaining(row -> books.add(new BookScienceRus().setLanguage(Language.RU).setTitle(row.getCell(0).getStringCellValue())));
        Sheet subjectsSheet = workbook.getSheet(RU_SUBJECT_SHEET);
        Sheet typesSheet = workbook.getSheet(RU_TYPE_SHEET);
        List<String> subjects = new ArrayList<>();
        List<String> types = new ArrayList<>();
        subjectsSheet.rowIterator().forEachRemaining(row -> subjects.add(row.getCell(0).getStringCellValue()));
        typesSheet.rowIterator().forEachRemaining(row -> types.add(row.getCell(0).getStringCellValue()));
        books.forEach(book -> {
            ((BookScience) book).setSubject(subjects.get(ThreadLocalRandom.current().nextInt(subjects.size())));
            ((BookScienceRus) book).setType(types.get(ThreadLocalRandom.current().nextInt(types.size())));
        });
    }

    private List<Book> readFiction(Workbook workbook, Language language) {
        List<Book> books = new ArrayList<>();
        Sheet bookNamesSheet = workbook.getSheet(language.equals(Language.EN) ? EN_FICTION_BOOK_SHEET : RU_FICTION_BOOK_SHEET);
        bookNamesSheet.rowIterator()
                .forEachRemaining(row -> books.add(new BookFiction().setLanguage(language).setTitle(row.getCell(0).getStringCellValue())));
        Sheet authorsSheet = workbook.getSheet(language.equals(Language.EN) ? EN_FICTION_AUTHOR_SHEET : RU_FICTION_AUTHOR_SHEET);
        List<String> authors = new ArrayList<>();
        authorsSheet.rowIterator()
                .forEachRemaining(row -> authors.add(row.getCell(0).getStringCellValue()));
        books.forEach(book -> book.setAuthor(authors.get(ThreadLocalRandom.current().nextInt(authors.size()))));
        return books;
    }

    public List<User> readUsers(String filename) throws IOException {
        Workbook workbook = getWorkbook(filename);
        List<User> users = new ArrayList<>();
        users.addAll(readStudents(workbook));
        users.addAll(readTeachers(workbook));
        return users;
    }

    private List<User> readStudents(Workbook workbook) {
        return readDefaultUsers(workbook, STUDENT_SURNAME_SHEET, Student.class);
    }

    private List<User> readTeachers(Workbook workbook)  {
        List<User> users = readDefaultUsers(workbook, TEACHER_SURNAME_SHEET, Teacher.class);
        addMiddleNames(workbook, users);
        return users;
    }

    private void addMiddleNames(Workbook workbook, List<User> users) {
        Sheet middlenamesSheet = workbook.getSheet(TEACHER_MIDDLENAME_SHEET);
        List<String> middlenames = new ArrayList<>();
        middlenamesSheet.rowIterator()
                .forEachRemaining(row -> middlenames.add(row.getCell(0).getStringCellValue()));
        users.forEach(user -> {
            String maleMiddlename = middlenames.get(ThreadLocalRandom.current().nextInt(middlenames.size()));
            if (user.getSex().equals(Sex.FEMALE)) {
                maleMiddlename = maleMiddlename.substring(0, maleMiddlename.length() - 2) + "на"; //0 - откуда начать, до чего
            }
            ((Teacher) user).setMiddleName(maleMiddlename);
        });
    }

    private List<User> readDefaultUsers(Workbook workbook, String surnameSheetName, Class<? extends User> userClass) {
        List<User> users = new ArrayList<>();
        Sheet namesSheet = workbook.getSheet(MALE_NAME_SHEET);
        Sheet wNamesSheet = workbook.getSheet(FEMALE_NAME_SHEET);
        namesSheet.rowIterator()
                .forEachRemaining(row -> users.add(createUser(row, Sex.MALE, userClass)));
        wNamesSheet.rowIterator()
                .forEachRemaining(row -> users.add(createUser(row, Sex.FEMALE, userClass)));
        Sheet surnameSheet = workbook.getSheet(surnameSheetName);
        List<String> surnames = new ArrayList<>();
        surnameSheet.rowIterator().forEachRemaining(row -> surnames.add(row.getCell(0).getStringCellValue()));
        users.forEach(user -> {
            String maleSurname = surnames.get(ThreadLocalRandom.current().nextInt(surnames.size()));//случайный номер из коллекции
            if (user.getSex().equals(Sex.MALE)) {
                user.setLastName(maleSurname);
            } else {
                user.setLastName(modifySurnameToFemale(maleSurname));
            }
        });
        return users;
    }

    private String modifySurnameToFemale(String maleSurname) {
        if (maleSurname.endsWith("ов") || maleSurname.endsWith("ин") || maleSurname.endsWith("ев") || maleSurname.endsWith("ёв")) {
            return maleSurname + "а";
        } else if (maleSurname.endsWith("кий")) {
            return maleSurname.substring(0, maleSurname.length() - 3) + "кая";
        } else {
            return maleSurname;
        }
    }

    private User createUser(Row row, Sex sex, Class<? extends User> userClass) {
        if (userClass.equals(Student.class)) {
            return new Student().setFirstName(row.getCell(0).getStringCellValue()).setSex(sex);
        } else if (userClass.equals(Teacher.class)) {
            return new Teacher().setFirstName(row.getCell(0).getStringCellValue()).setSex(sex);
        }
        return null;
    }

    // шаблонный метод
    protected abstract Workbook getWorkbook(String filename) throws IOException;

}
